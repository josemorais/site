# README #

### Para que? ###

* Para ter um serviço rest em java o mais rápido possivel.

### Como subir o serviço? ###

* Clone o projeto.
* rode o comando `mvn eclipse:eclipse`.
* importe no eclipse.
* adicione a um tomcat(no proprio eclipse)
* rode-o no browser acessando a utl: http://localhost:8080/simple_rest. Deverá aparecer o index.html com o texto "Seja bem vindo ao sistema..."
