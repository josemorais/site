package br.com.mr.exemplo;


public class HelloWorldIT {

}
